desc_pl=Konfiguracja inita (System&nbsp;V)
