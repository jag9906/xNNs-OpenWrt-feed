desc_pl=Start i&nbsp;zamykanie systemu
