Changelog
---------

0.3
===

+ Many fonts added
+ Char spacing support


0.2
===

+ Fonts support


Pre 0.0.1
=========

Initial commit
