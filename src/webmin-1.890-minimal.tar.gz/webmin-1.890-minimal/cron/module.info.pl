desc_pl=Harmonogram zadañ Cron
longdesc_pl=Twórz, edytuj i usuwaj zadania Cron.
